package com.app.comicapp.common

object Config {

    const val Url = "http://192.168.1.83:2001"

}