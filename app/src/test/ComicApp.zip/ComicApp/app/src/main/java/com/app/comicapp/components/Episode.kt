package com.app.comicapp.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Scale
import com.app.comicapp.R

@Composable
fun Episode(){
    val comicList = listOf(
        Comic(
            url = "https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",
            id = "188"
        ),
        Comic(
            url = "https://st.nettruyenus.com/data/comics/32/vo-luyen-dinh-phong.jpg",
            id = "32"
        ),
        Comic(
            url = "https://st.nettruyenus.com/data/comics/60/nguoi-xau.jpg",
            id = "60"
        ),
        Comic(
            url = "https://st.nettruyenus.com/data/comics/64/than-sung-tien-hoa-8970.jpg",
            id = "64"
        ),
        Comic(
            url = "https://st.nettruyenus.com/data/comics/234/dai-tuong-vo-hinh-4411.jpg",
            id = "234"
        )
    )

    LazyColumn( ) {
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
        item {
            EpisodesItem("https://st.nettruyenus.com/data/comics/188/dai-quan-gia-la-ma-hoang-904.jpg",10,10,"","")
        }
    }
}

@Composable
fun EpisodesItem(imgUrl: String, chapterNumber: Number, like:Number, date: String, id:String){
    Card (
        shape = RectangleShape,
        modifier = Modifier.padding(bottom = 2.dp ),
    ){
        Row(modifier = Modifier.height(100.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(imgUrl)
                    .crossfade(true)
                    .scale(Scale.FILL)
                    .build(),
                contentDescription = null,
                placeholder = painterResource(id = R.drawable.loading),
                error = painterResource(id = R.drawable.error),
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1.5f),
                contentScale = ContentScale.Crop
            )
            Column(
                modifier = Modifier
                    .weight(4f)
                    .padding(10.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Chapter $chapterNumber",
                    modifier = Modifier.padding(4.dp),
                    style = MaterialTheme.typography.labelLarge,
                )
                Row() {
                    Row {
                        Icon( Icons.Outlined.FavoriteBorder , contentDescription = null )
                        Text(
                            text = "59000",
                            modifier = Modifier.padding(5.dp),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    Text(
                        text = "Sep 29, 2023",
                        modifier = Modifier.padding(5.dp),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
            Text(
                text = "#$chapterNumber",
                modifier = Modifier.weight(0.5f),
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
            )

        }
        Divider(
            color = Color.Gray,
            thickness = 1.dp,
            modifier = Modifier.fillMaxWidth()
        )
    }
}