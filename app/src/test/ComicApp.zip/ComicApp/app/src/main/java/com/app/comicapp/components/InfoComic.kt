package com.app.comicapp.components

import androidx.compose.runtime.Composable

@Composable
fun InfoComic(){

}