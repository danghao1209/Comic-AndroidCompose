package com.app.comicapp.data.apis.user

import com.app.comicapp.data.entities.Comic
import com.app.comicapp.data.entities.ComicAll
import com.app.comicapp.data.entities.Comicn
import com.app.comicapp.data.entities.ListComic
import com.app.comicapp.data.entities.Stringn
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path

interface ComicApi {

    /**
     * example: https://jsonplaceholder.typicode.com/posts
     */
    @GET("/comics/{id}")
    suspend fun getCommicById(@Path("id") id: String,): Response<Comicn>

    @GET("/comics/get/all")
    suspend fun getAllCommic(): Response<List<ComicAll>>

    @GET("/")
    suspend fun getString(): Response<Stringn>
    @POST("/comics/subscribe")
    suspend fun subscribeComic(@Header("Authorization")token :String): Response<Comic>
}