package com.app.comicapp.data.entities

import android.os.Build
import androidx.annotation.RequiresApi
import com.squareup.moshi.Json

data class Comic(
    @Json(name = "_id")val _id: String,
    @Json(name = "title")val title: String,
    @Json(name = "description")val description: String,
    @Json(name = "thumbImg")val thumbImg: String,
    @Json(name = "previewImg")val previewImg: List<String>,
    @Json(name = "chapters")val chapters: List<Chapter>,
    @Json(name = "rate")val rate: List<Rate?>,
    @Json(name = "genre")val genre: String,
    @Json(name = "comment")val comment: List<String?>,
    @Json(name = "createdAt")val createdAt:String,
    @Json(name = "updatedAt")val updatedAt:String,
    @Json(name = "totalViews")val totalViews:Number,
    @Json(name = "__v")val __v:Number
)


data class Rate(
    val rate: Int,
    val userId: String
)

data class ComicAll @RequiresApi(Build.VERSION_CODES.O) constructor(
    @Json(name = "_id") var id: String,
    @Json(name = "title" ) var title: String,
    @Json(name = "description") var description: String,
    @Json(name = "thumbImg") var thumbImg: String,
    @Json(name = "previewImg") var previewImg: List<String>,
    @Json(name = "chapters") var chapters: List<String>,
    @Json(name = "rate") var rate: Any,
    @Json(name = "genre") var genre: String,
    @Json(name = "comment") var comment: Any,
)


data class Stringn(
     var title: String,
     @Json(name = "data") var hiihi: Any
)


data class ListComic(
    val items: List<ComicAll>? = emptyList()
)

data class Comicn(
    @Json(name = "_id") val id: String?,
    val title: String?,
    val description: String?,
    val thumbImg: String?,
    val previewImg: List<String>?,
    val chapters: List<String>?,
    val rate: List<Any>?,
    val genre: String?,
    val comment: List<Any>?,
    val totalViews: Int?
)