package com.app.comicapp.data.repositories

import android.util.Log
import com.app.comicapp.data.entities.Comic
import com.app.comicapp.data.entities.ComicAll
import com.app.comicapp.data.entities.Comicn
import com.app.comicapp.data.entities.ListComic
import com.app.comicapp.data.entities.Stringn
import com.app.comicapp.data.services.ComicService
import com.app.comicapp.di.IoDispatcher
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject

class ComicRepository @Inject constructor(
    private val comicService: ComicService,
    @IoDispatcher private val dispatcher: CoroutineDispatcher = Dispatchers.IO
) {

    suspend fun getComic(id:String): Comicn? = withContext(dispatcher) {
        comicService.getComic(id)
    }

    suspend fun getString(): Stringn? = withContext(dispatcher) {
        comicService.getString()
    }

    suspend fun getComics(): List<ComicAll>? = withContext(dispatcher) {
        comicService.getComics()
    }

}