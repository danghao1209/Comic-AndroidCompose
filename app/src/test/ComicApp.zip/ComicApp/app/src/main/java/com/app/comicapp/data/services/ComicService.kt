package com.app.comicapp.data.services

import android.util.Log
import com.app.comicapp.data.apis.user.ComicApi
import com.app.comicapp.data.entities.Comic
import com.app.comicapp.data.entities.ComicAll
import com.app.comicapp.data.entities.Comicn
import com.app.comicapp.data.entities.ListComic
import com.app.comicapp.data.entities.Stringn
import javax.inject.Inject

class ComicService @Inject constructor(private  val comicApi: ComicApi) {

    suspend fun getComics():  List<ComicAll>? {
        val response = comicApi.getAllCommic()
        if(response.isSuccessful){
            return response.body()
        }
        else{

            throw Exception(response.message())
        }
    }

    suspend fun getString(): Stringn? {

        val response = comicApi.getString()
        if(response.isSuccessful){
            return response.body()
        }
        else{

            throw Exception(response.message())
        }
    }


    suspend fun getComic(id:String): Comicn? {

        val response = comicApi.getCommicById(id)

        if(response.isSuccessful){
            return response.body()
        }
        else{

            throw Exception(response.message())
        }
    }

}