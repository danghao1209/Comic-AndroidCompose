package com.app.comicapp.ui.chapter

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.app.comicapp.base.BaseViewModel
import com.app.comicapp.data.entities.Chapter
import com.app.comicapp.data.repositories.ChapterRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ChapterViewModel @Inject constructor(private val chapterRepository: ChapterRepository, savedStateHandle: SavedStateHandle,):
    BaseViewModel(){
    var comic = MutableLiveData<Chapter?>()
        private set
    private val chapterId: String = checkNotNull(savedStateHandle["chapterId"])


    fun fetchData(chapterId: String?) {
        parentJob = viewModelScope.launch(exceptionHandler){
            isLoading.postValue(true)
            val newComic = chapterRepository.getChapter(this@ChapterViewModel.chapterId)

            comic.value = newComic
            isLoading.postValue(false)
        }
    }
}