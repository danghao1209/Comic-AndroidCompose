package com.app.comicapp.ui.comic

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.app.comicapp.components.HeaderComic
import com.app.comicapp.components.TabComic

@Composable
fun ComicScreen(comicViewModel: ComicViewModel = hiltViewModel(),navController: NavController = rememberNavController(), comicId:String?){
    LaunchedEffect(Unit) {
        comicViewModel.fetchData()
    }
    Surface(modifier = Modifier.fillMaxSize()) {
        Column( ){
            Row {
                HeaderComic()
            }
            Row {
                TabComic()
            }
        }
    }
}
