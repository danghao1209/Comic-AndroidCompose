package com.app.comicapp.ui.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.app.comicapp.base.BaseViewModel
import com.app.comicapp.data.database.entities.UserToken
import com.app.comicapp.data.entities.Comic
import com.app.comicapp.data.entities.ComicAll
import com.app.comicapp.data.entities.Comicn
import com.app.comicapp.data.entities.ListComic
import com.app.comicapp.data.repositories.ComicRepository
import com.app.comicapp.data.repositories.LocalRepository
import com.squareup.moshi.Json
import com.squareup.moshi.Moshi
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModal @Inject constructor(private val comicRepository: ComicRepository, val localRepository: LocalRepository, savedStateHandle: SavedStateHandle,):
    BaseViewModel(){
    var comic = MutableLiveData<List<ComicAll>?>()
        private set get

    var token = MutableLiveData<UserToken?>()
        private set get
    init {
        if (comicRepository == null) {
            throw IllegalStateException("Required value was null.")
        }
    }
    fun fetchData(){
        parentJob = viewModelScope.launch(exceptionHandler){
            isLoading.postValue(true)
            val newComic = comicRepository.getComics()
            Log.e("aa", newComic?.size.toString())
            comic.value = newComic
        }



        registerEventParentJobFinish()
    }

    fun getToken() {
        parentJob = viewModelScope.launch(exceptionHandler){
            isLoading.postValue(true)
            val tokenGet = localRepository.getToken()
            token.value =tokenGet
            Log.e("aa", tokenGet?.token.toString())
            isLoading.postValue(false)
        }
    }

}